# ISTQB CTFL 4.0 — PWA Bundle

## Files
- index.html     — Main app (fully self-contained, works offline)
- manifest.json  — PWA manifest
- icons/         — App icons (192x192 and 512x512)
- sw.js          — Service Worker for offline caching

## How to Install as an App

### Android APK (via PWABuilder)
1. Host index.html on any web server (GitHub Pages, Netlify, etc.)
2. Go to https://www.pwabuilder.com
3. Enter your hosted URL → click Start
4. Click "Android" → Download Package
5. Follow the signing instructions to get a signed .apk or .aab
6. Sideload the APK or publish to Google Play

### iOS (Safari)
1. Open index.html in Safari
2. Tap Share ⬆ → Add to Home Screen
3. The app appears on your home screen with the ISTQB icon

### Android (Chrome)
1. Open index.html in Chrome
2. Tap the ⋮ menu → Install App (or Add to Home Screen)
3. The app installs with the ISTQB icon

### Direct Offline Use
- index.html is 100% self-contained — works offline after first load
- No server required for the single-file version
